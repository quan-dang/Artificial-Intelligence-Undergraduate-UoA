p(X, Y):- q(X), r(Y).
q(X):- s(X).
r(Y):- t(Y).
s(a).
t(b).
